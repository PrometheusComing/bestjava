package com.best.java;

import javassist.*;

import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;

/**
 * @Author: xjxu3
 * @Date: 2019/12/24 13:59
 * @Description:
 */
public class MyClassFileTransFormer implements ClassFileTransformer {
	public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
		try {
			if (className == null) {
				return null;
			}
			className = className.replace("/", ".");
			ClassPool classPool = ClassPool.getDefault();
			if (className.startsWith("com.best.java")) {
				System.out.println("pre place:" + className + " " + loader);
			}
			classPool.insertClassPath(new ByteArrayClassPath(className,classfileBuffer));
			CtClass ctClass = classPool.get(className);
			CtMethod[] ctMethods = ctClass.getDeclaredMethods();
			for (CtMethod ctMethod:ctMethods ) {
				Object anno = ctMethod.getAnnotation(PrintTime.class);
				if (anno != null) {
					ctMethod.addLocalVariable("start",CtClass.longType);
					ctMethod.insertBefore("long start = System.currentTimeMillis();");
					ctMethod.insertAfter("System.out.println(System.currentTimeMillis() - start);");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return classfileBuffer;
	}
}
