package com.best.java;

import java.lang.instrument.Instrumentation;

/**
 * @Author: xjxu3
 * @Date: 2019/12/24 11:22
 * @Description:
 */
public class PreMainExecutor {

	public static void premain(String args, Instrumentation instrumentation) {
		System.out.println("preMain execute...");
		System.out.println("args is ：" + args);
		instrumentation.addTransformer(new MyClassFileTransFormer(),true);
//		instrumentation.appendToSystemClassLoaderSearch();
	}
}
