package com.best.java;

import java.lang.instrument.Instrumentation;

/**
 * @Author: xjxu3
 * @Date: 2019/12/24 17:48
 * @Description:
 */
public class AgentMainExecutor {
	public static void agentmain(String args, Instrumentation instrumentation) {
		System.out.println("agentmain execute...");
		System.out.println("args is ：" + args);
		instrumentation.addTransformer(new MyAgentClassTransFormer(),true);
	}
}
