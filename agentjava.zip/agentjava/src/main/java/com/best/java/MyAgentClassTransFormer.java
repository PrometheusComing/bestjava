package com.best.java;

import javassist.ByteArrayClassPath;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;

import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.nio.file.*;
import java.security.ProtectionDomain;

/**
 * @Author: xjxu3
 * @Date: 2019/12/24 18:01
 * @Description:
 */
public class MyAgentClassTransFormer implements ClassFileTransformer {


	public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
		try {
			if (className == null) {
				return null;
			}
			className = className.replace("/", ".");
			ClassPool classPool = ClassPool.getDefault();
			if (className.startsWith("com.best.java")) {
				System.out.println("agent place:" + className + " " + loader);
			}
			classPool.insertClassPath(new ByteArrayClassPath(className,classfileBuffer));
			CtClass ctClass = classPool.get(className);
			CtMethod[] ctMethods = ctClass.getDeclaredMethods();
			for (CtMethod ctMethod:ctMethods ) {
				Object anno = ctMethod.getAnnotation(PrintTime.class);
				if (anno != null) {
					ctMethod.addLocalVariable("start",CtClass.longType);
					ctMethod.insertBefore("start = System.currentTimeMillis();");
					ctMethod.insertAfter("System.out.println(\"method cost\" + (System.currentTimeMillis() - start) + \"ms\");");
//					Path path = Paths.get("C:\\Users\\prometheus\\Desktop\\TestController.class");
//					Files.write(path, ctClass.toBytecode(), StandardOpenOption.CREATE);
				}
			}
			return ctClass.toBytecode();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
